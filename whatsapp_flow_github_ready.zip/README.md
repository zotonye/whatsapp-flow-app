# WhatsApp Flow App

## What’s included
- Combined Backend + Auto-reply Bot
- WhatsApp Flow JSON (flow.json)

## How to deploy
1. Create a new GitHub repo
2. Upload all files from this folder
3. Go to https://render.com
4. Create a new Web Service → Connect GitHub repo
5. Select Node.js → Start Command: node server.js
6. Deploy
7. Copy the URL Render gives you → Paste it in WhatsApp Webhook URL
