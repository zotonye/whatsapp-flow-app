const express = require('express');
const app = express();
app.use(express.json());

// Backend Webhook
app.post('/webhook', (req, res) => {
    const msg = req.body.message?.toLowerCase() || "";
    let reply = "";
    if (msg.includes("airtime")) reply = "How much airtime would you like to buy?";
    else if (msg.includes("data")) reply = "Which data plan do you want?";
    else if (msg.includes("balance")) reply = "Please enter your phone number to check balance.";
    else reply = "Welcome! Reply with 'airtime', 'data', 'balance' or 'help'.";
    res.json({ reply });
});

// Auto-reply Bot
app.post('/reply', (req, res) => {
    const incoming = req.body.message || "";
    let response = "Welcome! Please choose: Airtime, Data, Balance, Bills.";
    if (/airtime/i.test(incoming)) response = "Enter airtime amount:";
    if (/data/i.test(incoming)) response = "Choose your data plan: 1GB, 2GB, 5GB.";
    if (/balance/i.test(incoming)) response = "Enter your phone number to check balance.";
    if (/bills/i.test(incoming)) response = "Choose type: TV or Electricity.";
    res.json({ response });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
